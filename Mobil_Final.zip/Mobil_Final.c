#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <stdbool.h>
#define ROW 16
#define COL 15

enum eMove
{
    kiri1,
    kiri2,
    kiri3,
    kiri4,
    kiri5,
    kanan1,
    kanan2,
    kanan3,
    kanan4,
    kanan5
};

void move_carR();
void move_carL();
void print_track();
void enemy1();
void enemy2();
void enemy3();
void enemy4();
void remove_o();
void car_crash();

int r, c, pass;
int row, col;
int pick_side = 0;
bool collision;

char track[ROW][COL] = {
"|            |",
"|            |",
"|            |",
"|            |",
"|            |",
"|            |",
"|            |",
"|            |",
"|            |",
"|            |",
"|            |",
"|            |",
"|o-o         |",
"|[o]         |",
"|o-o         |",
"|            |"};

int main()
{
    enum eMove position;

    position = kiri1;
    char ch;
    int count = 0;
    pass = 0;
    collision = false;

    print_track();

    while(count < 400)
   {
    if(collision == true)
        break;
	
    remove_o();
    
    if(pass % 15 == 0)
    {
        srand((unsigned) time(NULL));
        pick_side = rand() % 4;
        row = 0;
    }

    if(track[ROW-5][1] != ' ' & track[ROW-5][3] != ' ')
    	car_crash();
    else if (track[ROW-5][4] != ' ' & track[ROW-5][6] != ' ')
        car_crash();
    else if (track[ROW-5][7] != ' ' & track[ROW-5][9] != ' ') 
        car_crash();
    else if (track[ROW-5][10] != ' ' & track[ROW-5][12] != ' ')
        car_crash();
        
    else if (track[ROW-4][3] == ' '&&track[ROW-4][4] == '-')
        collision = true;
    else if (track[ROW-4][3] == '-'&&track[ROW-4][4] == ' ')
        collision = true;
    else if (track[ROW-2][3] == '-'&&track[ROW-2][4] == ' ')
        collision = true;
    else if (track[ROW-2][3] == ' '&&track[ROW-2][4] == '-')
        collision = true;
    
    else if (track[ROW-4][6] == ' '&&track[ROW-4][7] == '-')
        collision = true;
    else if (track[ROW-4][6] == '-' && track[ROW-4][7] == ' ')
        collision = true;
    else if (track[ROW-2][6] == '-' && track[ROW-2][7] == ' ')
        collision = true;
    else if (track[ROW-2][6] == ' ' && track[ROW-2][7] == '-')
        collision = true;
        
    else if (track[ROW-4][9] == ' ' && track[ROW-4][10] == '-')
        collision = true;
    else if (track[ROW-4][9] == '-' && track[ROW-4][10] == ' ')
        collision = true;
    else if (track[ROW-2][9] == '-' && track[ROW-2][10] == ' ')
        collision = true;
    else if (track[ROW-2][9] == ' ' && track[ROW-2][10] == '-')
        collision = true;

    if(pick_side == 0)
    {
        enemy2();
    }

    else if(pick_side==1)
    {
        enemy1();
    }
    else if(pick_side==2)
    {
        enemy4();
    }
    else if(pick_side==3)
    {
        enemy3();
    }

if(_kbhit())
{
         switch(ch = _getch())
    {
    case 'd':
        {
            if(position == kiri1)
            {
                move_carR();

                position = kiri2;
                break;
            }
            else if(position == kiri2)
            {
                move_carR();

                position = kiri3;
                break;
            }
            else if(position == kiri3)
            {
                move_carR();

                position = kiri4;
                break;
            }
            else if(position == kiri4)
            {
                move_carR();

                position = kiri5;
                break;
            }
            else if(position == kiri5)
            {
                move_carR();

                position = kanan1;
                break;
            }
            else if(position == kanan1)
            {
                move_carR();

                position = kanan2;
                break;
            }
            else if(position == kanan2)
            {
                move_carR();

                position = kanan3;
                break;
            }
            else if(position == kanan3)
            {
                move_carR();

                position = kanan4;
                break;
            }
            else if(position == kanan4)
            {
                move_carR();

                position = kanan5;
                break;
            }
            else
			{
            break;
			}
		}

    case 'a':
        {
            if(position == kanan5)
            {
                move_carL();

                position = kanan4;
                break;
            }
            else if(position == kanan4)
            {
                move_carL();

                position = kanan3;
                break;
            }
            else if(position == kanan3)
            {
                move_carL();

                position = kanan2;
                break;
            }
            else if(position == kanan2)
            {
                move_carL();

                position = kanan1;
                break;
            }
            else if(position == kanan1)
            {
                move_carL();

                position = kiri5;
                break;
            }
            else if(position == kiri5)
            {
                move_carL();

                position = kiri4;
                break;
            }
            else if(position == kiri4)
            {
                move_carL();

                position = kiri3;
                break;
            }
            else if(position == kiri3)
            {
                move_carL();

                position = kiri2;
                break;
            }
            else if(position == kiri2)
            {
                move_carL();

                position = kiri1;
                break;
            }
        }
        default:;
    }
}
    system("cls");
    print_track();
    count++;
   }
}

void print_track()
{
    system("COLOR 05");
    for(r = 3; r < ROW; r++)
    {
        printf("%s\n", track[r]);
    }

    printf("\nScore = %d", pass);
}

void move_carR()
{
  for(r = 14; r > ROW - 5; r--)
    {
        for(c = 12; c > COL - COL; c--)
        {
            if(track[r][c] == 'o')
            {
                track[r][c + 1] = 'o';
                track[r][c] = ' ';
            }
            else if (track[r][c] == '-')
			{
                track[r][c + 1] = '-';
                track[r][c] = ' ';
			}

			else if(track[r][c] == '[')
            {
                track[r][c + 1] = '[';
                track[r][c] = ' ';
            }
                
            else if(track[r][c] == ']')
            {
                track[r][c + 1] = ']';
                track[r][c] = ' ';
            }
                
            else if(track[r][c] == 'o')
            {
                track[r][c + 1] = 'o';
                track[r][c] = ' ';
            }
        }
    }
}

void move_carL()
{
   for(r = 12; r < ROW - 1; r++)
    {
        for(c = 1; c < COL; c++)
        {
            if(track[r][c] == 'o')
            {
                track[r][c-1] = 'o';
                track[r][c] = ' ';
            }
                
            else if(track[r][c] == '-')
            {
                track[r][c - 1] = '-';
                track[r][c] = ' ';
            }
                
            else if(track[r][c] == '[')
            {
                track[r][c - 1] = '[';
                track[r][c] = ' ';
            }
                
            else if(track[r][c] == ']')
            {
                track[r][c - 1] = ']';
                track[r][c] = ' ';
            }
                
            else if(track[r][c] == 'o')
            {
                track[r][c - 1] = 'o';
                track[r][c] = ' ';
            }
        }
    }
}

void enemy1(){

    track[row][4] = ' ';
    track[row][5] = ' ';
    track[row][6] = ' ';

    track[row+1][4] = ' ';
    track[row+1][5] = ' ';
    track[row+1][6] = ' ';

    track[row+2][4] = ' ';
    track[row+2][5] = ' ';
    track[row+2][6] = ' ';

	track[row][1] = ' ';
    track[row][2] = ' ';
    track[row][3] = ' ';

    track[row+1][1] = ' ';
    track[row+1][2] = ' ';
    track[row+1][3] = ' ';

    track[row+2][1] = ' ';
    track[row+2][2] = ' ';
    track[row+2][3] = ' ';
    
	row++;

    track[row][4] = '0';
    track[row][5] = '=';
    track[row][6] = '0';

	track[row+1][4] = '|';
    track[row+1][5] = '0';
    track[row+1][6] = '|';

    track[row+2][4] = '0';
    track[row+2][5] = '=';
    track[row+2][6] = '0';

	track[row][1] = '0';
    track[row][2] = '=';
    track[row][3] = '0';

	track[row+1][1] = '|';
    track[row+1][2] = '0';
    track[row+1][3] = '|';

    track[row+2][1] = '0';
    track[row+2][2] = '=';
    track[row+2][3] = '0';
    
    pass++;
    Beep(0,100);
}

void enemy2()
{

    track[row][1] = ' ';
    track[row][2] = ' ';
    track[row][3] = ' ';

    track[row+1][1] = ' ';
    track[row+1][2] = ' ';
    track[row+1][3] = ' ';

    track[row+2][1] = ' ';
    track[row+2][2] = ' ';
    track[row+2][3] = ' ';

	track[row][10] = ' ';
    track[row][11] = ' ';
    track[row][12] = ' ';

    track[row+1][10] = ' ';
    track[row+1][11] = ' ';
    track[row+1][12] = ' ';

    track[row+2][10] = ' ';
    track[row+2][11] = ' ';
    track[row+2][12] = ' ';
    
    row++;

    track[row][1] = '0';
    track[row][2] = '=';
    track[row][3] = '0';

	track[row+1][1] = '|';
    track[row+1][2] = '0';
    track[row+1][3] = '|';

    track[row+2][1] = '0';
    track[row+2][2] = '=';
    track[row+2][3] = '0';

	track[row][10] = '0';
    track[row][11] = '=';
    track[row][12] = '0';

    track[row+1][10] = '|';
    track[row+1][11] = '0';
    track[row+1][12] = '|';

    track[row+2][10] = '0';
    track[row+2][11] = '=';
    track[row+2][12] = '0';
    pass++;
    Beep(0,100);
}

void enemy3()
{

    track[row][7] = ' ';
    track[row][8] = ' ';
    track[row][9] = ' ';

    track[row+1][7] = ' ';
    track[row+1][8] = ' ';
    track[row+1][9] = ' ';

    track[row+2][7] = ' ';
    track[row+2][8] = ' ';
    track[row+2][9] = ' ';

	track[row][10] = ' ';
    track[row][11] = ' ';
    track[row][12] = ' ';

    track[row+1][10] = ' ';
    track[row+1][11] = ' ';
    track[row+1][12] = ' ';

    track[row+2][10] = ' ';
    track[row+2][11] = ' ';
    track[row+2][12] = ' ';
    
    row++;

    track[row][7] = '0';
    track[row][8] = '=';
    track[row][9] = '0';

    track[row+1][7] = '|';
    track[row+1][8] = '0';
    track[row+1][9] = '|';

    track[row+2][7] = '0';
    track[row+2][8] = '=';
    track[row+2][9] = '0';

	track[row][10] = '0';
    track[row][11] = '=';
    track[row][12] = '0';

    track[row+1][10] = '|';
    track[row+1][11] = '0';
    track[row+1][12] = '|';

    track[row+2][10] = '0';
    track[row+2][11] = '=';
    track[row+2][12] = '0';
    
    pass++;
    Beep(0,100);
}

void enemy4()
{

    track[row][10] = ' ';
    track[row][11] = ' ';
    track[row][12] = ' ';

    track[row+1][10] = ' ';
    track[row+1][11] = ' ';
    track[row+1][12] = ' ';

    track[row+2][10] = ' ';
    track[row+2][11] = ' ';
    track[row+2][12] = ' ';

	track[row][4] = ' ';
    track[row][5] = ' ';
    track[row][6] = ' ';

    track[row+1][4] = ' ';
    track[row+1][5] = ' ';
    track[row+1][6] = ' ';

    track[row+2][4] = ' ';
    track[row+2][5] = ' ';
    track[row+2][6] = ' ';
    
    row++;

    track[row][10] = '0';
    track[row][11] = '=';
    track[row][12] = '0';

    track[row+1][10] = '|';
    track[row+1][11] = '0';
    track[row+1][12] = '|';

    track[row+2][10] = '0';
    track[row+2][11] = '=';
    track[row+2][12] = '0';

	track[row][4] = '0';
    track[row][5] = '=';
    track[row][6] = '0';

	track[row+1][4] = '|';
    track[row+1][5] = '0';
    track[row+1][6] = '|';

    track[row+2][4] = '0';
    track[row+2][5] = '=';
    track[row+2][6] = '0';
    pass++;
    Beep(0,100);
}

void remove_o()
{
    track[ROW-1][1] = ' ';
    track[ROW-1][2] = ' ';
    track[ROW-1][3] = ' ';
    track[ROW-1][4] = ' ';
    track[ROW-1][5] = ' ';
    track[ROW-1][6] = ' ';
    track[ROW-1][7] = ' ';
    track[ROW-1][8] = ' ';
    track[ROW-1][9] = ' ';
    track[ROW-1][10] = ' ';
    track[ROW-1][11] = ' ';
    track[ROW-1][12] = ' ';
}

void car_crash()
{
    if(track[ROW-5][1] == '0' || track[ROW-5][2] == '0' || track[ROW-5][3] == '0')
    {
      if(track[ROW-4][1] == 'o' || track[ROW-4][2] == 'o' || track[ROW-4][3] == 'o')
            collision = true;
    }

    if (track[ROW-5][4] == '0' || track[ROW-5][5] == '0' || track[ROW-5][6] == '0')
    {
        if(track[ROW-4][4] == 'o'|| track[ROW-4][5] == 'o' || track[ROW-4][6] == 'o')
            collision = true;
    }
    
    if (track[ROW-5][7] == '0' || track[ROW-5][8] == '0' || track[ROW-5][9] == '0')
    {
        if(track[ROW-4][7] == 'o'|| track[ROW-4][8] == 'o' || track[ROW-4][9] == 'o')
            collision = true;
    }
    
    if (track[ROW-5][10] == '0' || track[ROW-5][11] == '0' || track[ROW-5][12] == '0')
    {
        if(track[ROW-4][10] == 'o'|| track[ROW-4][11] == 'o' || track[ROW-4][12] == 'o')
            collision = true;
    }
}
